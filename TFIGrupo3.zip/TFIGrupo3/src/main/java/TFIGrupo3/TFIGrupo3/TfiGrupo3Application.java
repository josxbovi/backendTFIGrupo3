package TFIGrupo3.TFIGrupo3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TfiGrupo3Application {

	public static void main(String[] args) {
		SpringApplication.run(TfiGrupo3Application.class, args);
	}

}
